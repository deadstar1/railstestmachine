
# mini_magick (4.5.1) RCE 